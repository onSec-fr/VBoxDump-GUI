1) Download .NET Core 3 Runtime : https://dotnet.microsoft.com/download/dotnet-core/current/runtime
2) Launch "VBoxDumpGUI.exe"